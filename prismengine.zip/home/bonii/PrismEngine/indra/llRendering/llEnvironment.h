void LL_Gemini_environment(){
    glClearColor(0.8,0.5,1.0,1.0);
}